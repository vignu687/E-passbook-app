package com.example.e_passbook

import org.json.JSONObject
import java.io.IOException
import android.widget.TextView
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val emailEditText = findViewById<EditText>(R.id.editTextTextEmailAddress2)
        val passwordEditText = findViewById<EditText>(R.id.editTextTextPassword)
        val loginButton = findViewById<Button>(R.id.button)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Your login logic goes here
            // For example, you could validate the email and password 
            // and show an error message if they are invalid.
            if (email.isNotEmpty() && password.isNotEmpty()) {
                // Example login logic
                if (email == "example@email.com" && password == "password") {
                    startActivity(Intent(this, AccountActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            }
        }
    }
}


    class AccountActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activiy_account)
        val goBackButton = findViewById<Button>(R.id.goBackButton)
        goBackButton.setOnClickListener {
            // Create an Intent to navigate back to MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // Close the current activity (optional)
        }

        val jsonString = readJsonFile()
        val jsonObject = JSONObject(jsonString)
        val name = jsonObject.getString("name")
        val address = jsonObject.getString("address")
        val balance = jsonObject.getString("balence")
        val credit = jsonObject.getString("credit")
        val debit = jsonObject.getString("debit")
        val date = jsonObject.getString("date")


        val accountInfoTextView = findViewById<TextView>(R.id.accountInfoTextView)
        accountInfoTextView.text = "Name: $name\nAddress: $address\nBalance: $balance\nCredit: $credit\nDebit: $debit\nDate: $date"

    }

    private fun readJsonFile(): String {
        val jsonString: String
        try {
            // Open the JSON file and read its contents
            val inputStream = assets.open("data.json")
            jsonString = inputStream.bufferedReader().use { it.readText() }
        } catch (e: IOException) {
            e.printStackTrace()
            return ""
        }
        return jsonString
    }
}

